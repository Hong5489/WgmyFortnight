<?php

$db = '__REDACTED__';
$db_host = '__REDACTED__';
$db_user = '__REDACTED__';
$db_pass = '__REDACTED__';

?>